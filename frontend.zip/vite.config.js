// server.js — основной файл backend
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import paymentRouter from "./routes/payment.js";
import generateRouter from "./routes/generate.js";
import downloadRouter from "./routes/download.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// static folders (serve previews and final videos)
app.use("/previews", express.static("previews"));
app.use("/videos", express.static("output"));

// API routes
app.use("/api/payment", paymentRouter);
app.use("/api/generate", generateRouter);
app.use("/api/download", downloadRouter);

// Ensure folders exist
import fs from "fs";
["uploads","previews","output","storage"].forEach(d=>{ if(!fs.existsSync(d)) fs.mkdirSync(d); });

const PORT = process.env.PORT || 4242;
app.listen(PORT, ()=> console.log(`Backend running on http://localhost:${PORT}`));
