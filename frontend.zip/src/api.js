export const API_BASE = "http://localhost:4242";

export const ENDPOINTS = {
  preview: `${API_BASE}/api/generate/preview`,
  createPayment: `${API_BASE}/api/payment/create`,
  final: `${API_BASE}/api/generate/final`,
  download: (token) => `${API_BASE}/api/download/${token}`,
};
