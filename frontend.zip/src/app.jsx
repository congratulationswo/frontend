import React from "react";
import OrderForm from "./components/OrderForm";

export default function App(){
  return <div style={{padding:20,fontFamily:'Arial, sans-serif'}}>
    <h1>Видео-поздравления</h1>
    <OrderForm />
  </div>;
}
