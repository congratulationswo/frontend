import React, {useState} from "react";
import axios from "axios";

export default function OrderForm(){
  const [photos,setPhotos]=useState([]);
  const [names,setNames]=useState("");
  const [message,setMessage]=useState("");
  const [scene,setScene]=useState("newyear");
  const [previewUrl,setPreviewUrl]=useState(null);
  const [downloadUrl,setDownloadUrl]=useState(null);
  const [loading,setLoading]=useState(false);

  async function genPreview(){
    setLoading(true);
    const fd = new FormData();
    photos.forEach(p=>fd.append("photos", p));
    fd.append("names", names);
    fd.append("message", message);
    fd.append("scene", scene);
    try {
      const res = await axios.post("/api/generate/preview", fd);
      setPreviewUrl(res.data.previewUrl);
    } catch (e) {
      alert("Ошибка preview: "+(e.response?.data?.error || e.message));
    } finally { setLoading(false); }
  }

  async function payAndGenerate(){
    setLoading(true);
    try {
      // 1) Create PaymentIntent
      const resPi = await axios.post("/api/payment/create", {
        basePrice: 20,
        namesCount: names.split(",").filter(Boolean).length,
        photosCount: photos.length,
        orderMeta: { scene }
      });
      alert("Симуляция оплаты: в продакшене подключите Stripe Elements/Checkout. Цена: €"+resPi.data.amountEuros);
      // 2) Start final generation (demo: call final endpoint)
      const fd = new FormData();
      photos.forEach(p=>fd.append("photos", p));
      fd.append("names", names);
      fd.append("message", message);
      fd.append("scene", scene);
      fd.append("orderId", Date.now());
      const res = await axios.post("/api/generate/final", fd, { timeout: 0 });
      setDownloadUrl(res.data.downloadUrl);
      alert("Генерация запущена и завершена (демо). Ссылка готова.");
    } catch (e) {
      alert("Ошибка финала: "+(e.response?.data?.error || e.message));
    } finally { setLoading(false); }
  }

  return (
    <div style={{maxWidth:760}}>
      <div style={{marginBottom:10}}>
        <label>Шаблон: </label>
        <select value={scene} onChange={e=>setScene(e.target.value)}>
          <option value="newyear">Новый год (Санта)</option>
          <option value="september">1 сентября (Сова)</option>
          <option value="birthday">День рождения</option>
          <option value="graduation">Последний звонок</option>
        </select>
      </div>

      <div style={{marginBottom:10}}>
        <input type="file" multiple onChange={e=>setPhotos([...e.target.files])}/>
      </div>

      <div style={{marginBottom:10}}>
        <input placeholder="Имена через запятую" value={names} onChange={e=>setNames(e.target.value)} style={{width:"100%",padding:8}}/>
      </div>

      <div style={{marginBottom:10}}>
        <textarea placeholder="Текст поздравления" value={message} onChange={e=>setMessage(e.target.value)} style={{width:"100%",height:120,padding:8}}/>
      </div>

      <div style={{display:"flex",gap:10}}>
        <button onClick={genPreview} disabled={loading}>Посмотреть 10с preview</button>
        <button onClick={payAndGenerate} disabled={loading}>Оплатить и сгенерировать финал</button>
      </div>

      {previewUrl && <div style={{marginTop:20}}><h3>Preview</h3><video src={previewUrl} controls width="640" /></div>}
      {downloadUrl && <div style={{marginTop:20}}><a href={downloadUrl} download>Скачать финальное видео</a></div>}
    </div>
  );
}
